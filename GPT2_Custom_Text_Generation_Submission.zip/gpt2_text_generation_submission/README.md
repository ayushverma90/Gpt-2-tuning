# GPT-2 Custom Text Generation

## Objective
Fine-tune GPT-2 on a custom text corpus so that it learns the style and structure of the training data and generates coherent text from a prompt.

## Files
- `train_gpt2.py` — complete training and generation code
- `data/train.txt` — sample custom training corpus
- `requirements.txt` — required Python packages
- `results/generated_result.png` — visual result of text generation
- `results/result.txt` — generated output shown in the PNG
- `README.md` — project instructions

## How to run
1. Install Python 3.9+.
2. Install dependencies:
   `pip install -r requirements.txt`
3. Run:
   `python train_gpt2.py`

A CUDA-capable GPU is recommended for faster fine-tuning. The included dataset is intentionally small for demonstration; a larger dataset generally produces better results.

## Expected result
The model is prompted with:
`Artificial intelligence is`

It then generates a continuation based on patterns learned during fine-tuning.
